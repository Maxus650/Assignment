package za.ac.tut.web;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import za.ac.tut.bl.AppointmentFacadeLocal;
import za.ac.tut.bl.ClientFacadeLocal;
import za.ac.tut.entities.Appointment;
import za.ac.tut.entities.Client;


public class AddClientServlet extends HttpServlet {

    @EJB
    private ClientFacadeLocal cf1;

    @EJB
    private AppointmentFacadeLocal af1;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
           
            String name = request.getParameter("name");
            String genderStr = request.getParameter("gender");
            Character gender = genderStr.charAt(0);
            String dateStr = request.getParameter("date");
            String time = request.getParameter("time");
            String type = request.getParameter("type");

            
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date date = sdf.parse(dateStr);

            
            Client client = createClient(name , gender);
            Appointment appointment = new Appointment(date, time, type, client);
            
            request.setAttribute("clientName", name);
            request.setAttribute("appointmentDate", dateStr);
            request.setAttribute("appointmentTime", time);
            request.setAttribute("appointmentType", type);

            
            cf1.create(client);
            af1.create(appointment);

            RequestDispatcher rd = request.getRequestDispatcher("add_client_outcome.jsp");
            rd.forward(request, response);
            
        } catch (Exception ex) {
            
            request.setAttribute("error", "Error booking appointment: " + ex.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }

    private Client createClient(String name, Character gender) {
        Client client = new Client();
        client.setName(name);
        client.setGender(gender);
        client.setCreationDate(new Date());
        return client;
    }
}
