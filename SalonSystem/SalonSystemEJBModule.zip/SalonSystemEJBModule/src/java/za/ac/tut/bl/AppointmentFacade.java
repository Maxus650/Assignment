/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.bl;

import za.ac.tut.bl.AbstractFacade;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import za.ac.tut.entities.Appointment;

/**
 *
 * @author ntomb
 */
@Stateless
public class AppointmentFacade extends AbstractFacade<Appointment> implements AppointmentFacadeLocal {

    @PersistenceContext(unitName = "SalonSystemEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public AppointmentFacade() {
        super(Appointment.class);
    }

    @Override
    public Long getCountPerAppointmentType(String appointmentType) {
    String queryStr = "SELECT COUNT(c) FROM Appointment c WHERE c.appointmentType = :appointmentType";
    Query query = em.createQuery(queryStr);
    query.setParameter("appointmentType", appointmentType);
    return (Long) query.getSingleResult();
    }

    
    
}
