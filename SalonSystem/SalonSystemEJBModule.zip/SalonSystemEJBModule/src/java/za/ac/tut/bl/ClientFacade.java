/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.bl;

import za.ac.tut.bl.AbstractFacade;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import za.ac.tut.entities.Client;

/**
 *
 * @author ntomb
 */
@Stateless
public class ClientFacade extends AbstractFacade<Client> implements ClientFacadeLocal {

    @PersistenceContext(unitName = "SalonSystemEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ClientFacade() {
        super(Client.class);
    }

    @Override
    public Long getClientsCount() {
        String queryStr ="SELECT COUNT(c) FROM Client c";
        Query query = em.createQuery(queryStr);
        Long cnt = (Long)query.getSingleResult();
        return cnt;
    }

    @Override
    public Long getCountMales() {
        String queryStr ="SELECT COUNT(c) FROM Client c WHERE c.gender = 'M'";
        Query query = em.createQuery(queryStr);
        Long cnt = (Long)query.getSingleResult();
        return cnt;
    }

    @Override
    public List<Client> getAll() {
        String queryStr ="SELECT c FROM Client c";
        Query query = em.createQuery(queryStr);
        List<Client> clients = query.getResultList();
        return clients;
    }

    @Override
    public List<Client> getAllPerGender(Character gender) {
        String queryStr ="SELECT c FROM Client c WHERE c.gender = :gender";
        Query query = em.createQuery(queryStr);
        query.setParameter("gender", gender);
        List<Client> clients = query.getResultList();
        return clients;
    }

    @Override
    public Long getCountFemales() {
        String queryStr ="SELECT COUNT(c) FROM Client c WHERE c.gender = 'F'";
        Query query = em.createQuery(queryStr);
        Long cnt = (Long)query.getSingleResult();
        return cnt;
    }
    
}
